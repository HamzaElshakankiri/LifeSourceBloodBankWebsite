
var form2 = document.getElementById("login-form");
form2.addEventListener("submit", validateLogin,false);